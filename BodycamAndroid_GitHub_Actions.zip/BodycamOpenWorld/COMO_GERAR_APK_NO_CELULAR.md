# Como gerar o APK pelo celular usando GitHub Actions

O workflow `.github/workflows/build-android.yml` compila o projeto Unity 2022.3.40f1 para Android e publica o APK como artefato da execução.

## 1. Enviar os arquivos ao GitHub

Envie o conteúdo desta pasta `BodycamOpenWorld` para a raiz do repositório `BodycamAndroid`, mantendo a pasta `.github/workflows` e o caminho `Assets`, `Packages` e `ProjectSettings`.

## 2. Configurar a licença Unity

O GameCI precisa de uma licença Unity válida. No GitHub, abra o repositório e vá em **Settings > Secrets and variables > Actions > New repository secret**. Configure:

- `UNITY_LICENSE`: conteúdo integral do arquivo de licença Unity `.ulf` da sua conta.
- `UNITY_EMAIL`: e-mail da conta Unity.
- `UNITY_PASSWORD`: senha da conta Unity.

Não coloque esses dados em arquivos do projeto, README ou mensagens públicas. A documentação do GameCI explica a ativação da licença: https://game.ci/docs/github/activation/ .

## 3. Iniciar a compilação

No GitHub, abra **Actions > Build Android APK > Run workflow**. Também haverá compilação automática quando houver push para `main` ou `master`.

## 4. Baixar no Android

Quando a execução terminar com sucesso, abra a execução em **Actions**, role até **Artifacts** e baixe `BODYCAM-OpenWorld-Android-APK`. Extraia o ZIP do artefato e toque no APK para instalar.

Se o workflow falhar, abra a execução e consulte o primeiro erro na etapa **Build APK with Unity**. A geração ainda não foi validada; o APK só existirá se a compilação terminar com sucesso.
